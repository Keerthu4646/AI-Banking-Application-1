import { useState, useEffect } from "react";
import api from "./api";

export default function App() {
  const [token, setToken] = useState(localStorage.getItem("token") || "");
  const [email, setEmail] = useState(""); const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState(""); const [accounts, setAccounts] = useState([]);
  const [transactions, setTransactions] = useState([]); const [fromAccountId, setFrom] = useState("");
  const [toAccountId, setTo] = useState(""); const [amount, setAmount] = useState(""); const [message, setMessage] = useState("");

  const loadAccounts = async () => setAccounts((await api.get("/accounts/")).data);
  const loadTransactions = async () => setTransactions((await api.get("/transactions/")).data);
  useEffect(() => { if (token) { loadAccounts(); loadTransactions(); } }, [token]);

  const register = async () => { await api.post(`/auth/register?email=${email}&full_name=${fullName}&password=${password}`); setMessage("Registered. Please log in."); };
  const login = async () => {
    const form = new FormData(); form.append("username", email); form.append("password", password);
    const response = await api.post("/auth/login", form);
    localStorage.setItem("token", response.data.access_token); setToken(response.data.access_token); setMessage("Logged in");
  };
  const createAccount = async () => { await api.post("/accounts/"); await loadAccounts(); };
  const transfer = async () => {
    await api.post(`/transactions/transfer?from_account_id=${fromAccountId}&to_account_id=${toAccountId}&amount=${amount}`);
    setAmount(""); await loadAccounts(); await loadTransactions(); setMessage("Transfer submitted");
  };
  const logout = () => { localStorage.removeItem("token"); setToken(""); };

  if (!token) return (
    <div style={{maxWidth:420, margin:"60px auto", fontFamily:"Arial"}}>
      <h1>Python Bank</h1>
      <input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
      <input placeholder="Full name" value={fullName} onChange={e=>setFullName(e.target.value)} />
      <input placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
      <button onClick={register}>Register</button>
      <button onClick={login}>Login</button>
      <p>{message}</p>
    </div>
  );

  return (
    <div style={{maxWidth:900, margin:"40px auto", fontFamily:"Arial"}}>
      <h1>Python Bank</h1>
      <button onClick={logout}>Logout</button>
      <h2>Accounts</h2>
      <button onClick={createAccount}>Create account</button>
      <ul>{accounts.map(a=><li key={a.id}>{a.account_number}: ₹{a.balance}</li>)}</ul>
      <h2>Transfer</h2>
      <select value={fromAccountId} onChange={e=>setFrom(e.target.value)}>
        <option value="">From account</option>
        {accounts.map(a=><option key={a.id} value={a.id}>{a.account_number}</option>)}
      </select>
      <select value={toAccountId} onChange={e=>setTo(e.target.value)}>
        <option value="">To account</option>
        {accounts.map(a=><option key={a.id} value={a.id}>{a.account_number}</option>)}
      </select>
      <input placeholder="Amount" type="number" value={amount} onChange={e=>setAmount(e.target.value)} />
      <button onClick={transfer}>Transfer</button>
      <h2>Transactions</h2>
      <ul>{transactions.map(t=><li key={t.id}>#{t.id} — {t.from_account_id} → {t.to_account_id}: ₹{t.amount} ({t.status})</li>)}</ul>
      <p>{message}</p>
    </div>
  );
}
